package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class segitiga extends AppCompatActivity {

    private Button btn_hasil;
    private EditText txt_alas, txt_tinggi, txt_sisi;
    private TextView hasilluas, hasilkeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilansegitiga);

        btn_hasil = findViewById(R.id.btn_hasil);
        txt_alas = findViewById(R.id.txt_alas);
        txt_tinggi = findViewById(R.id.txt_tinggi);
        txt_sisi = findViewById(R.id.txt_sisi);
        hasilkeliling = findViewById(R.id.hasilkeliling);
        hasilluas = findViewById(R.id.hasilluas);

        btn_hasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String angka1 = txt_alas.getText().toString();
                String angka2 = txt_tinggi.getText().toString();
                String angka3 = txt_sisi.getText().toString();

                if (angka1.isEmpty()) {
                    txt_alas.setError("Angka Harus Di Isi");
                    txt_alas.requestFocus();
                }else if (angka2.isEmpty()){
                    txt_tinggi.setError("Angka Harus Di Isi");
                    txt_tinggi.requestFocus();
                }else if (angka3.isEmpty()){
                    txt_sisi.setError("Angka Harus Di Isi");
                    txt_sisi.requestFocus();
                }else {
                    Double Alas = Double.parseDouble(angka1);
                    Double Tinggi = Double.parseDouble(angka2);
                    Double Sisi = Double.parseDouble((angka3));

                    Double keliling = Alas + Tinggi + Sisi ;
                    Double luas = 0.5 * (Alas * Tinggi);

                    hasilkeliling.setText(String.format("%.2f",keliling));
                    hasilluas.setText(String.format("%.2f",luas));
                }
            }
        });
        return;
    }
}