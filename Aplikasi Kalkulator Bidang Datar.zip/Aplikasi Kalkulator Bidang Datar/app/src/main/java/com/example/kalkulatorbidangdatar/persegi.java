package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class persegi extends AppCompatActivity {
    private Button btn_hasil;
    private EditText txt_panjang, txt_lebar;
    private TextView hasilluas, hasilkeliling;

    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilanpersegi);

        btn_hasil = findViewById(R.id.btn_hasil);
        txt_panjang = findViewById(R.id.txt_lebar);
        txt_lebar = findViewById(R.id.txt_lebar);
        hasilluas = findViewById(R.id.hasilluas);
        hasilkeliling = findViewById(R.id.hasilkeliling);

        btn_hasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String angka1 = txt_panjang.getText().toString();
                String angka2 = txt_lebar.getText().toString();

                if (angka1.isEmpty()) {
                    txt_panjang.setError("Angka Harus Di Isi");
                    txt_lebar.requestFocus();
                }else if (angka2.isEmpty()){
                    txt_lebar.setError("Angka Harus Di Isi");
                    txt_lebar.requestFocus();
                }else {
                    Integer Panjang = Integer.parseInt(angka1);
                    Integer Lebar = Integer.parseInt(angka2);

                    Integer keliling = 2 * (Panjang + Lebar);
                    Integer luas = Panjang * Lebar;

                    hasilkeliling.setText(String.valueOf(keliling));
                    hasilluas.setText(String.valueOf(luas));

                }
            }
        });
     return;
    }
}