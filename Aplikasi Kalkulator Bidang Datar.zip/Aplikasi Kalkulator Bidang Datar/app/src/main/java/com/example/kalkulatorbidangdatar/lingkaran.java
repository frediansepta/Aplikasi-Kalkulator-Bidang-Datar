package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class lingkaran extends AppCompatActivity {

    private Button btn_hasil;
    private EditText txt_diameter;
    private TextView hasilkeliling,hasilluas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilanlingkaran);

        btn_hasil = findViewById(R.id.btn_hasil);
        txt_diameter = findViewById(R.id.txt_diameter);
        hasilkeliling = findViewById(R.id.hasilkeliling);
        hasilluas = findViewById(R.id.hasilluas);

        btn_hasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String angka1 = txt_diameter.getText().toString();


                if (angka1.isEmpty()) {
                    txt_diameter.setError("Angka Harus Di Isi");
                    txt_diameter.requestFocus();
                }else {
                    Double Diameter = Double.parseDouble(angka1);

                    Double keliling = 3.14 * Diameter ;
                    Double luas = 3.14 * ((0.5 * Diameter)*(0.5 * Diameter));

                    hasilkeliling.setText(String.format("%.2f",keliling));
                    hasilluas.setText(String.format("%.2f",luas));

                }
            }
        });
        return;
    }
}